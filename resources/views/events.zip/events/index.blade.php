<x-app-layout>
    <div class="py-12" x-data="eventFinder()">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg mb-6 p-6">
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div class="col-span-2">
                        <label class="block text-sm font-medium text-gray-700">Esemény neve</label>
                        <input type="text" x-model="filters.keyword" @input.debounce.500ms="fetchEvents()" 
                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" 
                               placeholder="Pl. Techno Party...">
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Város</label>
                        <select x-model="filters.city_id" @change="fetchEvents()" 
                                class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">Összes város</option>
                            <template x-for="city in cities" :key="city.id">
                                <option :value="city.id" x-text="city.name"></option>
                            </template>
                        </select>
                    </div>

                    <div>
                        <label class="block text-sm font-medium text-gray-700">Mikortól?</label>
                        <input type="date" x-model="filters.date_from" @change="fetchEvents()" 
                               class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <template x-if="loading">
                    <div class="col-span-full text-center py-10 text-gray-500">
                        <svg class="animate-spin h-8 w-8 mx-auto mb-2 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                            <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        Események betöltése...
                    </div>
                </template>

                <template x-for="event in events" :key="event.id">
                    <div class="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow duration-300 flex flex-col h-full">
                        <div class="h-48 bg-gray-200 w-full relative">
                            <template x-if="event.image_url">
                                <img :src="event.image_url" class="w-full h-full object-cover">
                            </template>
                            <template x-if="!event.image_url">
                                <div class="flex items-center justify-center h-full text-gray-400">
                                    <span class="text-4xl">🎉</span>
                                </div>
                            </template>
                            
                            <div class="absolute top-2 right-2 bg-indigo-600 text-white text-xs font-bold px-2 py-1 rounded">
                                <span x-text="new Date(event.start_time).toLocaleDateString()"></span>
                            </div>
                        </div>

                        <div class="p-4 flex-1 flex flex-col">
                            <h3 class="text-lg font-bold text-gray-900 mb-1" x-text="event.title"></h3>
                            
                            <p class="text-sm text-gray-500 mb-2 flex items-center">
                                <svg class="w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                                <span x-text="event.location?.name || 'Ismeretlen helyszín'"></span>
                                <span class="mx-1">•</span>
                                <span x-text="event.location?.city?.name"></span>
                            </p>

                            <p class="text-gray-600 text-sm line-clamp-2 mb-4 flex-1" x-text="event.description"></p>

                            <div class="border-t pt-3 flex items-center justify-between mt-auto">
                                <div class="text-xs text-gray-500 font-semibold flex flex-col">
                                    <span>👥 <span x-text="event.real_attending_count"></span> ott lesz</span>
                                    <span>⭐ <span x-text="event.real_interested_count"></span> érdeklődik</span>
                                </div>
                                <a :href="'/events/' + event.id" class="bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-medium py-2 px-4 rounded transition">
                                    Részletek
                                </a>
                            </div>
                        </div>
                    </div>
                </template>
            </div>
            
            <div x-show="!loading && events.length === 0" class="text-center py-10 text-gray-500">
                Sajnos nem találtunk ilyen eseményt. 😔 Próbálj módosítani a szűrőkön!
            </div>

        </div>
    </div>

    <script>
        function eventFinder() {
            return {
                events: [],
                cities: [],
                loading: true,
                filters: {
                    keyword: '',
                    city_id: '',
                    date_from: new Date().toISOString().split('T')[0] // Mai dátum alapból
                },

                init() {
                    this.fetchCities();
                    this.fetchEvents();
                },

                fetchCities() {
                    // Városok betöltése a legördülőhöz
                    fetch('/api/cities')
                        .then(res => res.json())
                        .then(data => this.cities = data);
                },

                fetchEvents() {
                    this.loading = true;
                    
                    // Query string építése a szűrőkből
                    const params = new URLSearchParams(this.filters).toString();

                    fetch(`/api/events/filter?${params}`)
                        .then(res => res.json())
                        .then(data => {
                            this.events = data.data; // Mivel paginate()-et használtunk a Controllerben
                            this.loading = false;
                        })
                        .catch(err => {
                            console.error(err);
                            this.loading = false;
                        });
                }
            }
        }
    </script>
</x-app-layout>